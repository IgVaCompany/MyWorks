﻿using System.Collections.Generic;

namespace Terminal
{
    public class Test
    {      
        public string testName;
        public string validationSubSystem;
        public string statusOfValidationSubSystem;
        public string commandToSerialPort;        
    }
}