﻿namespace Terminal
{
    public class DataPort
    {
        public string nameOfPort;
        public string bandRateOfPOrt;
    }
}