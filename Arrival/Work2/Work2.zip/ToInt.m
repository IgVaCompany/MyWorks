function [ Out ] = ToInt( In )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Out = fix(In);

end

