function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 48};
	 this.metricsArray.var["rtInf"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 4};
	 this.metricsArray.var["rtM_"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 489};
	 this.metricsArray.var["rtMinusInf"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 4};
	 this.metricsArray.var["rtU"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.var["rtX"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.var["rtY"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	size: 8};
	 this.metricsArray.fcn["Control.c:rt_ertODEUpdateContinuousStates"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 200,
	stackTotal: -1};
	 this.metricsArray.fcn["Control_derivatives"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["Control_initialize"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 24};
	 this.metricsArray.fcn["Control_step"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 24,
	stackTotal: -1};
	 this.metricsArray.fcn["memcpy"] = {file: "C:\\Program Files\\MATLAB\\R2015b\\sys\\lcc\\include\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtGetInf"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetInfF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetMinusInf"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetMinusInfF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetNaN"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 20,
	stackTotal: 24};
	 this.metricsArray.fcn["rtGetNaNF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtIsInf"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsInfF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaN"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtIsNaNF"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rt_InitInfAndNaN"] = {file: "C:\\Users\\Druzhinin_Vasily\\Documents\\My_Project\\GAM\\trunk\\Arrival\\Work3\\Control_ert_rtw\\Control.c",
	stack: 0,
	stackTotal: 24};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data;}
}
	 CodeMetrics.instance = new CodeMetrics();
