function CodeDefine() { 
this.def = new Array();
this.def["rtX"] = {file: "Control_c.html",line:39,type:"var"};
this.def["rtDW"] = {file: "Control_c.html",line:42,type:"var"};
this.def["rtU"] = {file: "Control_c.html",line:45,type:"var"};
this.def["rtY"] = {file: "Control_c.html",line:48,type:"var"};
this.def["rtM_"] = {file: "Control_c.html",line:51,type:"var"};
this.def["rtM"] = {file: "Control_c.html",line:52,type:"var"};
this.def["BigEndianIEEEDouble"] = {file: "Control_c.html",line:76,type:"type"};
this.def["LittleEndianIEEEDouble"] = {file: "Control_c.html",line:83,type:"type"};
this.def["IEEESingle"] = {file: "Control_c.html",line:90,type:"type"};
this.def["rtInf"] = {file: "Control_c.html",line:92,type:"var"};
this.def["rtMinusInf"] = {file: "Control_c.html",line:93,type:"var"};
this.def["rtNaN"] = {file: "Control_c.html",line:94,type:"var"};
this.def["rtInfF"] = {file: "Control_c.html",line:95,type:"var"};
this.def["rtMinusInfF"] = {file: "Control_c.html",line:96,type:"var"};
this.def["rtNaNF"] = {file: "Control_c.html",line:97,type:"var"};
this.def["rtGetInf"] = {file: "Control_c.html",line:105,type:"fcn"};
this.def["rtGetInfF"] = {file: "Control_c.html",line:129,type:"fcn"};
this.def["rtGetMinusInf"] = {file: "Control_c.html",line:140,type:"fcn"};
this.def["rtGetMinusInfF"] = {file: "Control_c.html",line:164,type:"fcn"};
this.def["rt_ertODEUpdateContinuousStates"] = {file: "Control_c.html",line:175,type:"fcn"};
this.def["Control_step"] = {file: "Control_c.html",line:253,type:"fcn"};
this.def["Control_derivatives"] = {file: "Control_c.html",line:378,type:"fcn"};
this.def["Control_initialize"] = {file: "Control_c.html",line:388,type:"fcn"};
this.def["rt_InitInfAndNaN"] = {file: "Control_c.html",line:437,type:"fcn"};
this.def["rtIsInf"] = {file: "Control_c.html",line:449,type:"fcn"};
this.def["rtIsInfF"] = {file: "Control_c.html",line:455,type:"fcn"};
this.def["rtIsNaN"] = {file: "Control_c.html",line:461,type:"fcn"};
this.def["rtIsNaNF"] = {file: "Control_c.html",line:467,type:"fcn"};
this.def["rtGetNaN"] = {file: "Control_c.html",line:476,type:"fcn"};
this.def["rtGetNaNF"] = {file: "Control_c.html",line:500,type:"fcn"};
this.def["RT_MODEL"] = {file: "Control_h.html",line:145,type:"type"};
this.def["DW"] = {file: "Control_h.html",line:155,type:"type"};
this.def["X"] = {file: "Control_h.html",line:160,type:"type"};
this.def["XDot"] = {file: "Control_h.html",line:165,type:"type"};
this.def["XDis"] = {file: "Control_h.html",line:170,type:"type"};
this.def["ODE3_IntgData"] = {file: "Control_h.html",line:179,type:"type"};
this.def["ExtU"] = {file: "Control_h.html",line:186,type:"type"};
this.def["ExtY"] = {file: "Control_h.html",line:191,type:"type"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:49,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:50,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:51,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:52,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:55,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:62,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:63,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:64,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:65,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:66,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["creal32_T"] = {file: "rtwtypes_h.html",line:80,type:"type"};
this.def["creal64_T"] = {file: "rtwtypes_h.html",line:85,type:"type"};
this.def["creal_T"] = {file: "rtwtypes_h.html",line:90,type:"type"};
this.def["cint8_T"] = {file: "rtwtypes_h.html",line:97,type:"type"};
this.def["cuint8_T"] = {file: "rtwtypes_h.html",line:104,type:"type"};
this.def["cint16_T"] = {file: "rtwtypes_h.html",line:111,type:"type"};
this.def["cuint16_T"] = {file: "rtwtypes_h.html",line:118,type:"type"};
this.def["cint32_T"] = {file: "rtwtypes_h.html",line:125,type:"type"};
this.def["cuint32_T"] = {file: "rtwtypes_h.html",line:132,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:150,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["Control_c.html"] = "../Control.c";
	this.html2Root["Control_c.html"] = "Control_c.html";
	this.html2SrcPath["Control_h.html"] = "../Control.h";
	this.html2Root["Control_h.html"] = "Control_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.html2SrcPath["rtmodel_h.html"] = "../rtmodel.h";
	this.html2Root["rtmodel_h.html"] = "rtmodel_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"Control_c.html","Control_h.html","rtwtypes_h.html","rtmodel_h.html"];
