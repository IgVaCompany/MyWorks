function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["Control.c:274c7"]=1;
    this.traceFlag["Control.c:278c10"]=1;
    this.traceFlag["Control.c:279c9"]=1;
    this.traceFlag["Control.c:280c13"]=1;
    this.traceFlag["Control.c:286c11"]=1;
    this.traceFlag["Control.c:288c13"]=1;
    this.traceFlag["Control.c:294c13"]=1;
    this.traceFlag["Control.c:301c25"]=1;
    this.traceFlag["Control.c:302c25"]=1;
    this.traceFlag["Control.c:303c9"]=1;
    this.traceFlag["Control.c:304c12"]=1;
    this.traceFlag["Control.c:313c7"]=1;
    this.traceFlag["Control.c:322c17"]=1;
    this.traceFlag["Control.c:323c17"]=1;
    this.traceFlag["Control.c:324c7"]=1;
    this.traceFlag["Control.c:332c9"]=1;
    this.traceFlag["Control.c:336c16"]=1;
    this.traceFlag["Control.c:340c16"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
