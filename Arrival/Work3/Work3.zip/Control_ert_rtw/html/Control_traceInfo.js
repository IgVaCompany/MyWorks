function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Derivative */
	this.urlHashMap["Work3:17"] = "Control.c:276,307,330,350,425&Control.h:151,152,153,154";
	/* <S1>/Gain1 */
	this.urlHashMap["Work3:12"] = "Control.c:316";
	/* <S1>/Gain2 */
	this.urlHashMap["Work3:13"] = "Control.c:309&Control.h:150";
	/* <S1>/Gain3 */
	this.urlHashMap["Work3:14"] = "Control.c:270&Control.h:149";
	/* <S1>/Integrator */
	this.urlHashMap["Work3:16"] = "Control.c:318,383,429&Control.h:159,164,169";
	/* <S1>/Sum */
	this.urlHashMap["Work3:15"] = "Control.c:319";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "Control"};
	this.sidHashMap["Control"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "Work3:9"};
	this.sidHashMap["Work3:9"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S1>/In1"] = {sid: "Work3:10"};
	this.sidHashMap["Work3:10"] = {rtwname: "<S1>/In1"};
	this.rtwnameHashMap["<S1>/Derivative"] = {sid: "Work3:17"};
	this.sidHashMap["Work3:17"] = {rtwname: "<S1>/Derivative"};
	this.rtwnameHashMap["<S1>/Gain1"] = {sid: "Work3:12"};
	this.sidHashMap["Work3:12"] = {rtwname: "<S1>/Gain1"};
	this.rtwnameHashMap["<S1>/Gain2"] = {sid: "Work3:13"};
	this.sidHashMap["Work3:13"] = {rtwname: "<S1>/Gain2"};
	this.rtwnameHashMap["<S1>/Gain3"] = {sid: "Work3:14"};
	this.sidHashMap["Work3:14"] = {rtwname: "<S1>/Gain3"};
	this.rtwnameHashMap["<S1>/Integrator"] = {sid: "Work3:16"};
	this.sidHashMap["Work3:16"] = {rtwname: "<S1>/Integrator"};
	this.rtwnameHashMap["<S1>/Slider"] = {sid: "Work3:36"};
	this.sidHashMap["Work3:36"] = {rtwname: "<S1>/Slider"};
	this.rtwnameHashMap["<S1>/Slider1"] = {sid: "Work3:37"};
	this.sidHashMap["Work3:37"] = {rtwname: "<S1>/Slider1"};
	this.rtwnameHashMap["<S1>/Slider2"] = {sid: "Work3:38"};
	this.sidHashMap["Work3:38"] = {rtwname: "<S1>/Slider2"};
	this.rtwnameHashMap["<S1>/Sum"] = {sid: "Work3:15"};
	this.sidHashMap["Work3:15"] = {rtwname: "<S1>/Sum"};
	this.rtwnameHashMap["<S1>/Out1"] = {sid: "Work3:11"};
	this.sidHashMap["Work3:11"] = {rtwname: "<S1>/Out1"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
